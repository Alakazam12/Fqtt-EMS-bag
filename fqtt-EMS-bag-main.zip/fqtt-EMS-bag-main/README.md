# fqtt-EmsBag script for QB-Core

| If you are interested in joining my community: discord.gg/techout |
| For Question join the Discord or add me fqtt


# Information
* A Script That Would Allow Ems To carry a Their Job Bag   

# Required
Add this to **qb-core/shared/items.lua**
```
	["emsbag"]   	= {["name"] = "emsbag", 		["label"] = "emsbag", 	["weight"] = 150, 		["type"] = "item", 		["image"] = "emsbag.png", 			["unique"] = false,   	["useable"] = true,    ["shouldClose"] = true,    ["combinable"] = nil,   ["description"] = ""},

```
Add the image from the images/emsbag.png to your **qb-inventory/html/images/** folder
