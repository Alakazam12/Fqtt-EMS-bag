Config = {}


-- EMS Bag

Config.Bag = {
	Job = "ambulance",
}
Config.Stash = {
	MaxWeighStash = 50000,
	MaxSlotsStash = 50,
}
